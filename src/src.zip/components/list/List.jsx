import Card from "../card/Card";

export default function List({stdList}) {
    return (
        stdList.map((student) => (
            <Card name={student.name} age={student.age} pp={student.pp} key={student.name}/>
        ))
    );
}